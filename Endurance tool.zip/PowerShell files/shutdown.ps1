# Shutdown
Stop-Computer -Force
